package com.kalachittha.app

import android.os.Bundle
import androidx.activity.ComponentActivity
import androidx.activity.compose.setContent
import androidx.activity.compose.rememberLauncherForActivityResult
import androidx.activity.result.contract.ActivityResultContracts
import androidx.biometric.BiometricManager
import androidx.biometric.BiometricPrompt
import androidx.core.content.ContextCompat
import androidx.compose.foundation.background
import androidx.compose.foundation.clickable
import androidx.compose.foundation.layout.*
import androidx.compose.foundation.lazy.LazyColumn
import androidx.compose.foundation.lazy.items
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.foundation.text.KeyboardOptions
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.filled.*
import androidx.compose.material3.*
import androidx.compose.runtime.*
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.platform.LocalContext
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.text.input.KeyboardType
import androidx.compose.ui.text.input.PasswordVisualTransformation
import androidx.compose.ui.unit.dp
import androidx.fragment.app.FragmentActivity
import androidx.lifecycle.lifecycleScope
import com.kalachittha.app.data.*
import com.kalachittha.app.security.*
import com.kalachittha.app.ui.ResponseAssistant
import kotlinx.coroutines.flow.collectLatest
import kotlinx.coroutines.launch
import java.text.SimpleDateFormat
import java.util.*
import java.util.UUID

private val Ink = Color(0xFF111111)
private val Panel = Color(0xFF202020)
private val Crimson = Color(0xFFB84B50)
private val WarmWhite = Color(0xFFF3F0EB)
private val Muted = Color(0xFFAAA39C)

class MainActivity : FragmentActivity() {
    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        window.statusBarColor = android.graphics.Color.rgb(17,17,17)
        window.navigationBarColor = android.graphics.Color.rgb(17,17,17)
        setContent { KalaApp(this) }
    }
}

@Composable
private fun KalaApp(activity: FragmentActivity) {
    val context = LocalContext.current
    val db = remember { DatabaseProvider.get(context) }
    val dao = remember { db.dao() }
    val scope = rememberCoroutineScope()
    var unlocked by remember { mutableStateOf(false) }
    var pin by remember { mutableStateOf("") }
    var pinConfirm by remember { mutableStateOf("") }
    var pinError by remember { mutableStateOf("") }
    var isSetup by remember { mutableStateOf(!PinSecurity.isSet(context)) }
    var language by remember { mutableStateOf(context.getSharedPreferences("kc_ui", 0).getString("language", "EN") ?: "EN") }
    val setLanguage: (String) -> Unit = { value -> language = value; context.getSharedPreferences("kc_ui", 0).edit().putString("language", value).apply() }
    var tab by remember { mutableStateOf("HOME") }
    var search by remember { mutableStateOf("") }
    var showAdd by remember { mutableStateOf(false) }
    var selected by remember { mutableStateOf<IncidentWithPerson?>(null) }
    var total by remember { mutableIntStateOf(0) }
    var pending by remember { mutableIntStateOf(0) }
    var resolved by remember { mutableIntStateOf(0) }
    var incidents by remember { mutableStateOf(emptyList<IncidentWithPerson>()) }
    var people by remember { mutableStateOf(emptyList<Person>()) }
    var backupPassword by remember { mutableStateOf("") }
    var message by remember { mutableStateOf("") }
    var pendingBackupUri by remember { mutableStateOf<android.net.Uri?>(null) }
    var pendingRestoreUri by remember { mutableStateOf<android.net.Uri?>(null) }
    var showBackupPassword by remember { mutableStateOf(false) }
    var backupMode by remember { mutableStateOf("EXPORT") }

    val exportLauncher = rememberLauncherForActivityResult(ActivityResultContracts.CreateDocument("application/octet-stream")) { uri ->
        if (uri != null) { pendingBackupUri = uri; backupMode = "EXPORT"; showBackupPassword = true }
    }
    val importLauncher = rememberLauncherForActivityResult(ActivityResultContracts.OpenDocument()) { uri ->
        if (uri != null) { pendingRestoreUri = uri; backupMode = "IMPORT"; showBackupPassword = true }
    }

    LaunchedEffect(Unit) {
        launch { dao.observeIncidents().collectLatest { incidents = it } }
        launch { dao.observePeople().collectLatest { people = it } }
        launch { dao.observeTotal().collectLatest { total = it } }
        launch { dao.observePending().collectLatest { pending = it } }
        launch { dao.observeResolved().collectLatest { resolved = it } }
    }

    MaterialTheme(colorScheme = darkColorScheme(background = Ink, surface = Panel, primary = Crimson, onBackground = WarmWhite, onSurface = WarmWhite)) {
        Surface(Modifier.fillMaxSize(), color = Ink) {
            if (!unlocked) {
                LockScreen(isSetup, pin, { pin = it.take(12) }, pinConfirm, { pinConfirm = it.take(12) }, pinError,
                    onSubmit = {
                        if (isSetup) {
                            if (pin.length < 4 || pin.any { !it.isDigit() }) pinError = if (language == "HI") "कम से कम 4 अंकों का PIN डालें" else "Enter a numeric PIN with at least 4 digits"
                            else if (pin != pinConfirm) pinError = if (language == "HI") "PIN मेल नहीं खाता" else "PINs do not match"
                            else { PinSecurity.setPin(context, pin); isSetup = false; unlocked = true; pin = ""; pinConfirm = "" }
                        } else if (PinSecurity.verify(context, pin)) { unlocked = true; pin = ""; pinError = "" }
                        else { pinError = if (language == "HI") "गलत PIN" else "Incorrect PIN"; pin = "" }
                    }, onBiometric = {
                        val manager = BiometricManager.from(context)
                        if (manager.canAuthenticate(BiometricManager.Authenticators.BIOMETRIC_STRONG or BiometricManager.Authenticators.DEVICE_CREDENTIAL) == BiometricManager.BIOMETRIC_SUCCESS) {
                            val prompt = BiometricPrompt(activity, ContextCompat.getMainExecutor(context), object : BiometricPrompt.AuthenticationCallback() {
                                override fun onAuthenticationSucceeded(result: BiometricPrompt.AuthenticationResult) { unlocked = true; pinError = "" }
                                override fun onAuthenticationError(errorCode: Int, errString: CharSequence) { pinError = errString.toString() }
                            })
                            prompt.authenticate(BiometricPrompt.PromptInfo.Builder().setTitle("Unlock KALA CHITTHA").setSubtitle("Authenticate to open your private records").setAllowedAuthenticators(BiometricManager.Authenticators.BIOMETRIC_STRONG or BiometricManager.Authenticators.DEVICE_CREDENTIAL).build())
                        } else pinError = if (language == "HI") "इस डिवाइस पर बायोमेट्रिक्स उपलब्ध नहीं" else "Biometrics are unavailable on this device"
                    }, language = language, onLanguage = { setLanguage(it) })
            } else {
                Column(Modifier.fillMaxSize()) {
                    Header(language, onLock = { unlocked = false }, onLanguage = { setLanguage(if (language == "EN") "HI" else "EN") })
                    when (tab) {
                        "HOME" -> HomeScreen(language, total, pending, resolved, incidents, onAdd = { showAdd = true }, onSelect = { selected = it }, onAll = { tab = "RECORDS" })
                        "PEOPLE" -> PeopleScreen(language, people, incidents, search, { search = it }, { personId -> incidents.firstOrNull { it.person.id == personId }?.let { selected = it } })
                        "RECORDS" -> RecordsScreen(language, incidents, search, { search = it }, { selected = it })
                        else -> SettingsScreen(language, onExport = { exportLauncher.launch("kala-chittha-backup.kcb") }, onImport = { importLauncher.launch(arrayOf("application/octet-stream", "application/*")) }, onLock = { unlocked = false })
                    }
                    NavigationBar(containerColor = Panel, contentColor = WarmWhite) {
                        listOf("HOME" to Icons.Default.Home, "PEOPLE" to Icons.Default.People, "RECORDS" to Icons.Default.MenuBook, "SETTINGS" to Icons.Default.Settings).forEach { (key, icon) ->
                            NavigationBarItem(selected = tab == key, onClick = { tab = key }, icon = { Icon(icon, null) }, label = { Text(navLabel(key, language)) }, colors = NavigationBarItemDefaults.colors(selectedIconColor = Crimson, selectedTextColor = WarmWhite, indicatorColor = Color(0xFF382426), unselectedIconColor = Muted, unselectedTextColor = Muted))
                        }
                    }
                }
            }
        }
    }

    if (showAdd) AddIncidentDialog(language, people, onDismiss = { showAdd = false }, onSave = { personName, category, description, date, source ->
        scope.launch {
            val normalized = personName.trim().lowercase(Locale.ROOT)
            val person = dao.findPerson(normalized) ?: Person(UUID.randomUUID().toString(), personName.trim(), normalized).also { dao.insertPerson(it) }
            dao.insertIncident(Incident(UUID.randomUUID().toString(), person.id, category, description.trim(), date, source))
            showAdd = false
        }
    })

    selected?.let { item ->
        IncidentDetailDialog(language, item, onDismiss = { selected = null }, onStatus = { status, note ->
            scope.launch {
                val old = dao.getIncident(item.incident.id) ?: return@launch
                dao.updateIncident(old.copy(status = status, resolutionNote = note, updatedAt = System.currentTimeMillis()))
                dao.insertAudit(AuditEntry(UUID.randomUUID().toString(), old.id, old.status, status, note))
                selected = null
            }
        })
    }

    if (showBackupPassword) AlertDialog(onDismissRequest = { showBackupPassword = false; backupPassword = "" }, containerColor = Panel,
        title = { Text(if (backupMode == "EXPORT") (if (language == "HI") "बैकअप पासवर्ड" else "Backup password") else (if (language == "HI") "बैकअप खोलें" else "Unlock backup"), color = WarmWhite) },
        text = { Column { Text(if (language == "HI") "कम से कम 8 अक्षरों का पासवर्ड रखें। इसे सुरक्षित रखें; इसके बिना बैकअप वापस नहीं खुलेगा।" else "Use at least 8 characters. Keep this password safe; it cannot be recovered if lost.", color = Muted); Spacer(Modifier.height(8.dp)); OutlinedTextField(backupPassword, { backupPassword = it }, label = { Text("Password") }, visualTransformation = PasswordVisualTransformation()) } },
        confirmButton = { TextButton(onClick = {
            scope.launch {
                try {
                    if (backupMode == "EXPORT") pendingBackupUri?.let { BackupManager.export(dao, it, backupPassword, context); message = if (language == "HI") "बैकअप सेव हो गया" else "Encrypted backup saved" }
                    else pendingRestoreUri?.let { BackupManager.restore(dao, it, backupPassword, context); message = if (language == "HI") "बैकअप रीस्टोर हो गया" else "Backup restored" }
                } catch (e: Exception) { message = e.message ?: "Backup operation failed" }
                showBackupPassword = false; backupPassword = ""
            }
        }) { Text(if (language == "HI") "जारी रखें" else "Continue", color = Crimson) } },
        dismissButton = { TextButton(onClick = { showBackupPassword = false }) { Text(if (language == "HI") "रद्द करें" else "Cancel", color = Muted) } })
    if (message.isNotBlank()) AlertDialog(onDismissRequest = { message = "" }, title = { Text(if (language == "HI") "सूचना" else "Notice") }, text = { Text(message) }, confirmButton = { TextButton(onClick = { message = "" }) { Text("OK") } })
}

private fun navLabel(key: String, lang: String) = when (key) {
    "HOME" -> if (lang == "HI") "होम" else "Home"
    "PEOPLE" -> if (lang == "HI") "लोग" else "People"
    "RECORDS" -> if (lang == "HI") "रिकॉर्ड" else "Records"
    else -> if (lang == "HI") "सेटिंग्स" else "Settings"
}

@Composable private fun Header(language: String, onLock: () -> Unit, onLanguage: () -> Unit) {
    Row(Modifier.fillMaxWidth().background(Ink).padding(horizontal = 20.dp, vertical = 16.dp), verticalAlignment = Alignment.CenterVertically) {
        Column(Modifier.weight(1f)) { Text("KALA CHITTHA", color = WarmWhite, fontWeight = FontWeight.Bold, style = MaterialTheme.typography.titleLarge); Text(if (language == "HI") "आपकी निजी रिकॉर्ड बुक" else "YOUR PRIVATE RECORD BOOK", color = Muted, style = MaterialTheme.typography.labelSmall) }
        TextButton(onClick = onLanguage) { Text(language, color = Crimson) }
        IconButton(onClick = onLock) { Icon(Icons.Default.Lock, null, tint = WarmWhite) }
    }
}

@Composable private fun LockScreen(isSetup: Boolean, pin: String, onPin: (String) -> Unit, confirm: String, onConfirm: (String) -> Unit, error: String, onSubmit: () -> Unit, onBiometric: () -> Unit, language: String, onLanguage: (String) -> Unit) {
    Column(Modifier.fillMaxSize().padding(28.dp), horizontalAlignment = Alignment.CenterHorizontally, verticalArrangement = Arrangement.Center) {
        Icon(Icons.Default.MenuBook, null, tint = Crimson, modifier = Modifier.size(54.dp))
        Spacer(Modifier.height(16.dp)); Text("KALA CHITTHA", color = WarmWhite, style = MaterialTheme.typography.headlineMedium, fontWeight = FontWeight.Bold)
        Text(if (language == "HI") "हर बात का एक रिकॉर्ड" else "Every action has a record.", color = Muted)
        Spacer(Modifier.height(32.dp))
        Text(if (isSetup) (if (language == "HI") "अपना PIN बनाएं" else "Create your private PIN") else (if (language == "HI") "अपना PIN डालें" else "Enter your PIN"), color = WarmWhite)
        Spacer(Modifier.height(12.dp))
        OutlinedTextField(pin, onPin, label = { Text(if (language == "HI") "PIN" else "PIN") }, visualTransformation = PasswordVisualTransformation(), keyboardOptions = KeyboardOptions(keyboardType = KeyboardType.NumberPassword), singleLine = true)
        if (isSetup) { Spacer(Modifier.height(8.dp)); OutlinedTextField(confirm, onConfirm, label = { Text(if (language == "HI") "PIN दोबारा डालें" else "Confirm PIN") }, visualTransformation = PasswordVisualTransformation(), keyboardOptions = KeyboardOptions(keyboardType = KeyboardType.NumberPassword), singleLine = true) }
        if (error.isNotBlank()) Text(error, color = Color(0xFFFF8A80), modifier = Modifier.padding(8.dp))
        Spacer(Modifier.height(16.dp)); Button(onClick = onSubmit, colors = ButtonDefaults.buttonColors(containerColor = Crimson), modifier = Modifier.fillMaxWidth()) { Text(if (isSetup) (if (language == "HI") "PIN सेव करें" else "Set PIN") else (if (language == "HI") "अनलॉक करें" else "Unlock")) }
        if (!isSetup) { TextButton(onClick = onBiometric) { Icon(Icons.Default.Fingerprint, null); Spacer(Modifier.width(8.dp)); Text(if (language == "HI") "फिंगरप्रिंट से अनलॉक" else "Unlock with fingerprint") } }
        TextButton(onClick = { onLanguage(if (language == "EN") "HI" else "EN") }) { Text(if (language == "EN") "हिन्दी" else "English", color = Muted) }
        Spacer(Modifier.height(18.dp)); Text(if (language == "HI") "आपके रिकॉर्ड केवल इसी डिवाइस पर रहते हैं।" else "Your records stay on this device.", color = Muted, style = MaterialTheme.typography.bodySmall)
    }
}

@Composable private fun HomeScreen(language: String, total: Int, pending: Int, resolved: Int, incidents: List<IncidentWithPerson>, onAdd: () -> Unit, onSelect: (IncidentWithPerson) -> Unit, onAll: () -> Unit) {
    Column(Modifier.fillMaxSize().padding(18.dp)) {
        Text(if (language == "HI") "आपका डैशबोर्ड" else "Your dashboard", color = WarmWhite, style = MaterialTheme.typography.headlineSmall, fontWeight = FontWeight.SemiBold)
        Spacer(Modifier.height(16.dp))
        Row(horizontalArrangement = Arrangement.spacedBy(10.dp)) {
            StatCard(if (language == "HI") "कुल रिकॉर्ड" else "Total records", total.toString(), Modifier.weight(1f))
            StatCard(if (language == "HI") "लंबित" else "Pending", pending.toString(), Modifier.weight(1f), Color(0xFFD6A04D))
            StatCard(if (language == "HI") "हल" else "Resolved", resolved.toString(), Modifier.weight(1f), Color(0xFF79B68A))
        }
        Spacer(Modifier.height(18.dp))
        Button(onClick = onAdd, modifier = Modifier.fillMaxWidth(), colors = ButtonDefaults.buttonColors(containerColor = Crimson), shape = RoundedCornerShape(12.dp)) { Icon(Icons.Default.Add, null); Spacer(Modifier.width(8.dp)); Text(if (language == "HI") "नया रिकॉर्ड जोड़ें" else "ADD NEW RECORD") }
        Spacer(Modifier.height(22.dp))
        Row(verticalAlignment = Alignment.CenterVertically) { Text(if (language == "HI") "हाल के रिकॉर्ड" else "Recent records", color = WarmWhite, style = MaterialTheme.typography.titleMedium, modifier = Modifier.weight(1f)); TextButton(onClick = onAll) { Text(if (language == "HI") "सभी देखें" else "VIEW ALL", color = Crimson) } }
        if (incidents.isEmpty()) EmptyState(language) else LazyColumn(verticalArrangement = Arrangement.spacedBy(10.dp)) { items(incidents.take(8), key = { it.incident.id }) { IncidentCard(language, it, onSelect) } }
    }
}

@Composable private fun StatCard(label: String, value: String, modifier: Modifier, valueColor: Color = WarmWhite) {
    Column(modifier.background(Panel, RoundedCornerShape(14.dp)).padding(12.dp)) { Text(value, color = valueColor, style = MaterialTheme.typography.headlineMedium, fontWeight = FontWeight.Bold); Text(label, color = Muted, style = MaterialTheme.typography.labelSmall) }
}

@Composable private fun EmptyState(language: String) {
    Column(Modifier.fillMaxWidth().padding(top = 48.dp), horizontalAlignment = Alignment.CenterHorizontally) { Icon(Icons.Default.Book, null, tint = Muted, modifier = Modifier.size(42.dp)); Spacer(Modifier.height(10.dp)); Text(if (language == "HI") "अभी कोई रिकॉर्ड नहीं" else "No records yet", color = WarmWhite); Text(if (language == "HI") "पहला निजी रिकॉर्ड जोड़ें।" else "Add your first private record.", color = Muted, style = MaterialTheme.typography.bodySmall) }
}

@Composable private fun IncidentCard(language: String, item: IncidentWithPerson, onClick: (IncidentWithPerson) -> Unit) {
    Row(Modifier.fillMaxWidth().background(Panel, RoundedCornerShape(14.dp)).clickable { onClick(item) }.padding(14.dp), verticalAlignment = Alignment.CenterVertically) {
        Column(Modifier.weight(1f)) { Text(item.person.name, color = WarmWhite, fontWeight = FontWeight.SemiBold); Text("${item.incident.category} · ${date(item.incident.incidentDate)}", color = Muted, style = MaterialTheme.typography.bodySmall); Text(item.incident.description, color = WarmWhite, style = MaterialTheme.typography.bodyMedium, maxLines = 2) }
        Spacer(Modifier.width(8.dp)); StatusPill(item.incident.status, language)
    }
}

@Composable private fun StatusPill(status: String, language: String) {
    val (label, color) = when (status) { "RESOLVED" -> (if (language == "HI") "हल" else "Resolved") to Color(0xFF79B68A); "DISPUTED" -> (if (language == "HI") "विवादित" else "Disputed") to Color(0xFFB58BD0); "DISCUSSION" -> (if (language == "HI") "चर्चा" else "Discussion") to Color(0xFF77A9D1); else -> (if (language == "HI") "लंबित" else "Pending") to Color(0xFFD6A04D) }
    Text(label, color = color, style = MaterialTheme.typography.labelSmall, modifier = Modifier.background(color.copy(alpha = .13f), RoundedCornerShape(50)).padding(horizontal = 9.dp, vertical = 6.dp))
}

@Composable private fun RecordsScreen(language: String, incidents: List<IncidentWithPerson>, search: String, onSearch: (String) -> Unit, onSelect: (IncidentWithPerson) -> Unit) {
    Column(Modifier.fillMaxSize().padding(18.dp)) { Text(if (language == "HI") "सभी रिकॉर्ड" else "All records", color = WarmWhite, style = MaterialTheme.typography.headlineSmall); Spacer(Modifier.height(12.dp)); SearchBox(language, search, onSearch); Spacer(Modifier.height(12.dp)); val filtered = incidents.filter { it.person.name.contains(search, true) || it.incident.description.contains(search, true) || it.incident.category.contains(search, true) }; LazyColumn(verticalArrangement = Arrangement.spacedBy(10.dp)) { items(filtered, key = { it.incident.id }) { IncidentCard(language, it, onSelect) } } }
}

@Composable private fun PeopleScreen(language: String, people: List<Person>, incidents: List<IncidentWithPerson>, search: String, onSearch: (String) -> Unit, onSelect: (String) -> Unit) {
    Column(Modifier.fillMaxSize().padding(18.dp)) { Text(if (language == "HI") "लोग" else "People", color = WarmWhite, style = MaterialTheme.typography.headlineSmall); Spacer(Modifier.height(12.dp)); SearchBox(language, search, onSearch); Spacer(Modifier.height(12.dp)); LazyColumn(verticalArrangement = Arrangement.spacedBy(8.dp)) { items(people.filter { it.name.contains(search, true) }, key = { it.id }) { person -> val count = incidents.count { it.person.id == person.id }; Row(Modifier.fillMaxWidth().background(Panel, RoundedCornerShape(12.dp)).clickable { onSelect(person.id) }.padding(15.dp), verticalAlignment = Alignment.CenterVertically) { Icon(Icons.Default.Person, null, tint = Crimson); Spacer(Modifier.width(12.dp)); Column(Modifier.weight(1f)) { Text(person.name, color = WarmWhite, fontWeight = FontWeight.Medium); Text(if (language == "HI") "$count रिकॉर्ड" else "$count records", color = Muted, style = MaterialTheme.typography.bodySmall) }; Icon(Icons.Default.ChevronRight, null, tint = Muted) } } } }
}

@Composable private fun SearchBox(language: String, value: String, onValue: (String) -> Unit) { OutlinedTextField(value, onValue, modifier = Modifier.fillMaxWidth(), placeholder = { Text(if (language == "HI") "नाम या रिकॉर्ड खोजें" else "Search name or record") }, leadingIcon = { Icon(Icons.Default.Search, null) }, singleLine = true) }

@Composable private fun SettingsScreen(language: String, onExport: () -> Unit, onImport: () -> Unit, onLock: () -> Unit) {
    Column(Modifier.fillMaxSize().padding(18.dp)) { Text(if (language == "HI") "सेटिंग्स" else "Settings", color = WarmWhite, style = MaterialTheme.typography.headlineSmall); Spacer(Modifier.height(16.dp)); Text(if (language == "HI") "बैकअप और रीस्टोर" else "Backup & restore", color = Muted); SettingsRow(Icons.Default.Lock, if (language == "HI") "एन्क्रिप्टेड बैकअप बनाएं" else "Create encrypted backup", onExport); SettingsRow(Icons.Default.Restore, if (language == "HI") "बैकअप रीस्टोर करें" else "Restore backup", onImport); Spacer(Modifier.height(16.dp)); Text(if (language == "HI") "सुरक्षा" else "Security", color = Muted); SettingsRow(Icons.Default.Fingerprint, if (language == "HI") "ऐप लॉक करें" else "Lock app now", onLock); Spacer(Modifier.height(20.dp)); Text(if (language == "HI") "बैकअप पासवर्ड भूलने पर उसे वापस नहीं पाया जा सकता। बैकअप फ़ाइल और पासवर्ड अलग सुरक्षित रखें।" else "A backup password cannot be recovered. Store the backup file and its password separately and safely.", color = Muted, style = MaterialTheme.typography.bodySmall) }
}

@Composable private fun SettingsRow(icon: androidx.compose.ui.graphics.vector.ImageVector, label: String, onClick: () -> Unit) { Row(Modifier.fillMaxWidth().clickable { onClick() }.padding(vertical = 16.dp), verticalAlignment = Alignment.CenterVertically) { Icon(icon, null, tint = Crimson); Spacer(Modifier.width(14.dp)); Text(label, color = WarmWhite, modifier = Modifier.weight(1f)); Icon(Icons.Default.ChevronRight, null, tint = Muted) }; Divider(color = Panel) }

@OptIn(ExperimentalMaterial3Api::class)
@Composable private fun AddIncidentDialog(language: String, people: List<Person>, onDismiss: () -> Unit, onSave: (String, String, String, Long, String) -> Unit) {
    var name by remember { mutableStateOf("") }; var category by remember { mutableStateOf("Misbehaviour") }; var description by remember { mutableStateOf("") }; var source by remember { mutableStateOf("FIRST_HAND") }; var error by remember { mutableStateOf("") }
    val categories = listOf("Misbehaviour", "Backbiting / Gossip", "Broken commitment", "Dishonesty (disputed)", "Miscommunication", "Other")
    AlertDialog(onDismissRequest = onDismiss, containerColor = Panel, title = { Text(if (language == "HI") "नया रिकॉर्ड" else "New incident record", color = WarmWhite) },
        text = { Column(verticalArrangement = Arrangement.spacedBy(8.dp)) {
            OutlinedTextField(name, { name = it }, label = { Text(if (language == "HI") "व्यक्ति का नाम" else "Person's name") }, singleLine = true)
            var expanded by remember { mutableStateOf(false) }
            ExposedDropdownMenuBox(expanded = expanded, onExpandedChange = { expanded = !expanded }) { OutlinedTextField(category, {}, readOnly = true, label = { Text(if (language == "HI") "श्रेणी" else "Category") }, modifier = Modifier.menuAnchor().fillMaxWidth(), trailingIcon = { ExposedDropdownMenuDefaults.TrailingIcon(expanded) }); ExposedDropdownMenu(expanded, { expanded = false }) { categories.forEach { DropdownMenuItem(text = { Text(it) }, onClick = { category = it; expanded = false }) } } }
            OutlinedTextField(description, { description = it }, label = { Text(if (language == "HI") "क्या हुआ? तथ्यात्मक विवरण" else "What happened? Factual description") }, minLines = 3)
            Text(if (language == "HI") "जानकारी का स्रोत" else "Source of information", color = Muted, style = MaterialTheme.typography.labelMedium)
            Row(verticalAlignment = Alignment.CenterVertically) { RadioButton(source == "FIRST_HAND", { source = "FIRST_HAND" }); Text(if (language == "HI") "मैंने स्वयं देखा" else "First-hand", color = WarmWhite); RadioButton(source == "REPORTED", { source = "REPORTED" }); Text(if (language == "HI") "किसी ने बताया" else "Reported", color = WarmWhite) }
            if (error.isNotBlank()) Text(error, color = Color(0xFFFF8A80))
        } }, confirmButton = { TextButton(onClick = { if (name.isBlank() || description.isBlank()) error = if (language == "HI") "नाम और विवरण जरूरी हैं" else "Name and description are required" else onSave(name, category, description, System.currentTimeMillis(), source) }) { Text(if (language == "HI") "सेव करें" else "Save", color = Crimson) } }, dismissButton = { TextButton(onClick = onDismiss) { Text(if (language == "HI") "रद्द करें" else "Cancel", color = Muted) } })
}

@Composable private fun IncidentDetailDialog(language: String, item: IncidentWithPerson, onDismiss: () -> Unit, onStatus: (String, String) -> Unit) {
    var note by remember(item.incident.id) { mutableStateOf(item.incident.resolutionNote) }
    var responseDraft by remember(item.incident.id) { mutableStateOf("") }
    var categoryExpanded by remember { mutableStateOf(false) }
    AlertDialog(onDismissRequest = onDismiss, containerColor = Panel, title = { Text(item.person.name, color = WarmWhite) },
        text = { Column(verticalArrangement = Arrangement.spacedBy(8.dp)) { Text(item.incident.category, color = Crimson, fontWeight = FontWeight.SemiBold); Text(date(item.incident.incidentDate), color = Muted, style = MaterialTheme.typography.labelSmall); Text(item.incident.description, color = WarmWhite); Text(if (item.incident.sourceType == "REPORTED") (if (language == "HI") "स्रोत: किसी अन्य से प्राप्त जानकारी" else "Source: Reported by someone else") else (if (language == "HI") "स्रोत: प्रत्यक्ष अनुभव" else "Source: First-hand account"), color = Muted, style = MaterialTheme.typography.bodySmall); StatusPill(item.incident.status, language); OutlinedTextField(note, { note = it }, label = { Text(if (language == "HI") "अपडेट / समाधान नोट" else "Update / resolution note") }, minLines = 2); TextButton(onClick = { responseDraft = ResponseAssistant.draft(item.incident.category, item.incident.description, language == "HI") }) { Icon(Icons.Default.AutoAwesome, null, tint = Crimson); Spacer(Modifier.width(6.dp)); Text(if (language == "HI") "जवाब का सुझाव बनाएं" else "Draft a suggested response", color = Crimson) }; if (responseDraft.isNotBlank()) { Text(if (language == "HI") "सुझाया गया जवाब – भेजने से पहले समीक्षा करें" else "Suggested reply – review before using", color = Muted, style = MaterialTheme.typography.labelSmall); OutlinedTextField(responseDraft, { responseDraft = it }, minLines = 3); TextButton(onClick = { note = (if (note.isBlank()) "" else note + "\n\n") + (if (language == "HI") "ड्राफ्ट जवाब: " else "Draft reply: ") + responseDraft }) { Text(if (language == "HI") "ड्राफ्ट को नोट में जोड़ें" else "Add draft to notes", color = Crimson) } }; TextButton(onClick = { categoryExpanded = true }) { Text(if (language == "HI") "स्थिति बदलें" else "Change status", color = Crimson) }; DropdownMenu(expanded = categoryExpanded, onDismissRequest = { categoryExpanded = false }) { listOf("PENDING", "DISCUSSION", "DISPUTED", "RESOLVED").forEach { s -> DropdownMenuItem(text = { Text(s) }, onClick = { categoryExpanded = false; onStatus(s, note) }) } }; Text(if (language == "HI") "रिकॉर्ड निजी है। रिपोर्टेड जानकारी को सत्यापित तथ्य न मानें।" else "Private record. Reported information is not automatically verified fact.", color = Muted, style = MaterialTheme.typography.labelSmall) } }, confirmButton = { TextButton(onClick = { onStatus(item.incident.status, note) }) { Text(if (language == "HI") "नोट सेव करें" else "Save note", color = Crimson) } }, dismissButton = { TextButton(onClick = onDismiss) { Text(if (language == "HI") "बंद करें" else "Close", color = Muted) } })
}

private fun date(millis: Long): String = SimpleDateFormat("dd MMM yyyy", Locale.getDefault()).format(Date(millis))
