package com.kalachittha.app.data

import androidx.room.*
import kotlinx.coroutines.flow.Flow

@Entity(tableName = "people", indices = [Index(value = ["normalizedName"], unique = true)])
data class Person(
    @PrimaryKey val id: String,
    val name: String,
    val normalizedName: String,
    val notes: String = "",
    val createdAt: Long = System.currentTimeMillis()
)

@Entity(tableName = "incidents", foreignKeys = [ForeignKey(entity = Person::class, parentColumns = ["id"], childColumns = ["personId"], onDelete = ForeignKey.CASCADE)], indices = [Index("personId"), Index("status")])
data class Incident(
    @PrimaryKey val id: String,
    val personId: String,
    val category: String,
    val description: String,
    val incidentDate: Long,
    val sourceType: String,
    val status: String = "PENDING",
    val resolutionNote: String = "",
    val createdAt: Long = System.currentTimeMillis(),
    val updatedAt: Long = System.currentTimeMillis()
)

@Entity(tableName = "audit")
data class AuditEntry(
    @PrimaryKey val id: String,
    val incidentId: String,
    val oldStatus: String,
    val newStatus: String,
    val note: String,
    val changedAt: Long = System.currentTimeMillis()
)

data class IncidentWithPerson(
    @Embedded val incident: Incident,
    @Relation(parentColumn = "personId", entityColumn = "id") val person: Person
)

@Dao
interface KalaDao {
    @Transaction
    @Query("SELECT * FROM incidents ORDER BY updatedAt DESC")
    fun observeIncidents(): Flow<List<IncidentWithPerson>>

    @Query("SELECT * FROM people ORDER BY name COLLATE NOCASE")
    fun observePeople(): Flow<List<Person>>

    @Query("SELECT * FROM people WHERE normalizedName = :normalized LIMIT 1")
    suspend fun findPerson(normalized: String): Person?

    @Insert(onConflict = OnConflictStrategy.ABORT)
    suspend fun insertPerson(person: Person)

    @Insert(onConflict = OnConflictStrategy.ABORT)
    suspend fun insertIncident(incident: Incident)

    @Update
    suspend fun updateIncident(incident: Incident)

    @Insert
    suspend fun insertAudit(entry: AuditEntry)

    @Query("SELECT * FROM incidents WHERE id = :id LIMIT 1")
    suspend fun getIncident(id: String): Incident?

    @Query("SELECT * FROM people WHERE id = :id LIMIT 1")
    suspend fun getPerson(id: String): Person?

    @Query("SELECT COUNT(*) FROM incidents")
    fun observeTotal(): Flow<Int>

    @Query("SELECT COUNT(*) FROM incidents WHERE status = 'PENDING' OR status = 'DISCUSSION'")
    fun observePending(): Flow<Int>

    @Query("SELECT COUNT(*) FROM incidents WHERE status = 'RESOLVED'")
    fun observeResolved(): Flow<Int>

    @Query("SELECT * FROM audit ORDER BY changedAt DESC")
    suspend fun allAudit(): List<AuditEntry>

    @Query("SELECT * FROM people ORDER BY createdAt")
    suspend fun allPeople(): List<Person>

    @Query("SELECT * FROM incidents ORDER BY createdAt")
    suspend fun allIncidents(): List<Incident>

    @Query("DELETE FROM audit")
    suspend fun clearAudit()
    @Query("DELETE FROM incidents")
    suspend fun clearIncidents()
    @Query("DELETE FROM people")
    suspend fun clearPeople()
}

@Database(entities = [Person::class, Incident::class, AuditEntry::class], version = 1, exportSchema = false)
abstract class KalaDatabase : RoomDatabase() {
    abstract fun dao(): KalaDao
}
