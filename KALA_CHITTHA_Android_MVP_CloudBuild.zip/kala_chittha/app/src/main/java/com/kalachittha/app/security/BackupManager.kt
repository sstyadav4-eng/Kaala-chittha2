package com.kalachittha.app.security

import android.content.Context
import android.net.Uri
import android.util.Base64
import com.google.gson.Gson
import com.kalachittha.app.data.*
import kotlinx.coroutines.Dispatchers
import kotlinx.coroutines.withContext
import java.io.InputStream
import java.io.OutputStream
import java.security.SecureRandom
import javax.crypto.Cipher
import javax.crypto.SecretKeyFactory
import javax.crypto.spec.GCMParameterSpec
import javax.crypto.spec.PBEKeySpec
import javax.crypto.spec.SecretKeySpec

data class BackupPayload(val formatVersion: Int = 1, val exportedAt: Long = System.currentTimeMillis(), val people: List<Person>, val incidents: List<Incident>, val audit: List<AuditEntry>)

object BackupManager {
    private val gson = Gson()
    suspend fun export(dao: KalaDao, uri: Uri, password: String, context: Context) = withContext(Dispatchers.IO) {
        require(password.length >= 8) { "Backup password must be at least 8 characters." }
        val payload = BackupPayload(people = dao.allPeople(), incidents = dao.allIncidents(), audit = dao.allAudit())
        val plain = gson.toJson(payload).toByteArray(Charsets.UTF_8)
        val salt = ByteArray(16).also { SecureRandom().nextBytes(it) }
        val key = derive(password, salt)
        val cipher = Cipher.getInstance("AES/GCM/NoPadding").apply { init(Cipher.ENCRYPT_MODE, key) }
        val bytes = "KCBK1".toByteArray() + salt + cipher.iv + cipher.doFinal(plain)
        context.contentResolver.openOutputStream(uri)?.use { it.write(bytes) } ?: error("Cannot open backup destination")
    }
    suspend fun restore(dao: KalaDao, uri: Uri, password: String, context: Context) = withContext(Dispatchers.IO) {
        val bytes = context.contentResolver.openInputStream(uri)?.use { it.readBytes() } ?: error("Cannot read backup")
        require(bytes.size > 33 && String(bytes.copyOfRange(0, 5)) == "KCBK1") { "Not a KALA CHITTHA backup." }
        val salt = bytes.copyOfRange(5, 21)
        val iv = bytes.copyOfRange(21, 33)
        val cipherText = bytes.copyOfRange(33, bytes.size)
        val cipher = Cipher.getInstance("AES/GCM/NoPadding").apply { init(Cipher.DECRYPT_MODE, derive(password, salt), GCMParameterSpec(128, iv)) }
        val payload = gson.fromJson(String(cipher.doFinal(cipherText), Charsets.UTF_8), BackupPayload::class.java)
        require(payload.formatVersion == 1) { "Unsupported backup version." }
        dao.clearAudit(); dao.clearIncidents(); dao.clearPeople()
        payload.people.forEach { dao.insertPerson(it) }
        payload.incidents.forEach { dao.insertIncident(it) }
        payload.audit.forEach { dao.insertAudit(it) }
    }
    private fun derive(password: String, salt: ByteArray): SecretKeySpec {
        val spec = PBEKeySpec(password.toCharArray(), salt, 200_000, 256)
        return SecretKeySpec(SecretKeyFactory.getInstance("PBKDF2WithHmacSHA256").generateSecret(spec).encoded, "AES")
    }
}
