package com.kalachittha.app.ui

/** Local, deterministic drafting helper. No incident data leaves the device. */
object ResponseAssistant {
    fun draft(category: String, description: String, hindi: Boolean): String {
        val safeSummary = description.trim().take(220)
        return if (hindi) {
            "हमारे बीच एक बात अभी स्पष्ट या हल नहीं हुई है। मेरे नोट के अनुसार: $safeSummary\n\nमैं चाहता/चाहती हूँ कि हम इस पर शांति से बात करें और आपका पक्ष भी समझें।"
        } else {
            "There is an issue between us that I would like to clarify. My private note says: $safeSummary\n\nI'd prefer that we discuss it calmly and hear both perspectives before deciding how to move forward."
        }
    }
}
