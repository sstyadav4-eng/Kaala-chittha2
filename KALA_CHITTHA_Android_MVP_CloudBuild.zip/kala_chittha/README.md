# KALA CHITTHA — Android MVP

A private, offline-first incident journal for Android. Records are stored locally in a SQLCipher-encrypted Room database. The app does not upload contacts, incidents, or evidence to a server.

## Included in this starter MVP

- Kotlin + Jetpack Compose Android app
- First-launch PIN setup and PIN unlock
- Biometric / device-credential unlock when supported
- SQLCipher-encrypted local Room database; database key wrapped by Android Keystore
- Private people directory and incident records
- Search by person name, category, and description
- Pending, discussion, disputed, and resolved statuses
- Status-change audit entries
- English/Hindi UI toggle for core navigation and workflows
- Local response-draft helper; suggestions are editable and never sent automatically
- Manual password-encrypted backup and restore using Android's document picker

## Open in Android Studio

1. Install Android Studio with Android SDK 35 and JDK 17.
2. Open this folder (`kala_chittha`) in Android Studio.
3. Allow Gradle sync and dependency downloads.
4. Run the `app` configuration on an Android 10+ device or emulator.

The Gradle wrapper properties are included. If your checkout does not include the wrapper scripts/JAR, use Android Studio's Gradle integration or generate a wrapper with Gradle 8.9.

## Important implementation notes

- The app is offline-first. AI response drafting in this MVP is a local template helper, not a connected generative-AI service. A real AI provider can be added behind the `ResponseAssistant` interface after explicit user opt-in and privacy review.
- Biometric unlock uses Android BiometricPrompt. PIN is the fallback. Device credential may be accepted by Android depending on device capability.
- The SQLCipher passphrase is encrypted with an Android Keystore AES-GCM key. If the app is uninstalled or device Keystore data is lost, the local database may not be recoverable; keep encrypted backups.
- Backup files use PBKDF2-HMAC-SHA256 and AES-256-GCM. The backup password is not stored. Losing it means the backup cannot be restored.
- Restore replaces the current local records. Export a backup before restoring if you need to preserve existing records.
- Incident entries are private user notes, not verified findings. Keep reported information distinguished from first-hand observations; do not use this app as a public blacklist or for automated accusations.

## Suggested next engineering steps

1. Add automated Room/database and backup round-trip tests.
2. Add edit-person, delete-record, and evidence attachment screens.
3. Add backup confirmation and a pre-restore safety backup.
4. Add app lifecycle relock timeout and screenshot protection.
5. Add formal Hindi translations for all category/status labels.
6. Conduct a security review before storing highly sensitive personal information or publishing to Play Store.

## Build verification status

This environment did not have Gradle or an Android SDK installed, so an APK could not be compiled or device-tested here. Open the project in Android Studio and run Gradle sync/build there. Treat this as an implementation starter that needs a local build and QA pass before production use.

## Build an APK using only an Android phone (cloud build)

This project includes `.github/workflows/android-apk.yml`. GitHub Actions builds the APK on GitHub's cloud runners; Android Studio is not required on your phone.

### One-time setup

1. Create a free account at https://github.com/ using your phone browser and verify your email.
2. Install Termux from its official F-Droid page: https://f-droid.org/packages/com.termux/ (avoid unofficial APK mirrors).
3. Download this project ZIP to your phone and extract it with your file manager. Keep the `kala_chittha` project folder.
4. In Termux, grant storage access when prompted, then run:

```sh
termux-setup-storage
pkg update -y
pkg install git gh -y
cd ~/storage/downloads/kala_chittha
```

If your extracted folder is elsewhere, change the `cd` path accordingly. If the ZIP was extracted into a folder with a different name, use that exact folder.

5. Sign in to GitHub from Termux:

```sh
gh auth login
```

Choose GitHub.com, HTTPS, and authenticate in your phone browser when prompted.

6. Create a private repository and push the project:

```sh
git init
git add .
git commit -m "Initial KALA CHITTHA Android MVP"
git branch -M main
gh repo create kala-chittha-android --private --source=. --remote=origin --push
```

If Git asks for your name/email first, set them with `git config --global user.name "Your Name"` and `git config --global user.email "your-verified-email@example.com"`, then repeat the commit and repository-create commands.

### Download the APK

1. Open your new repository on github.com in your phone browser.
2. Select **Actions** → **Build KALA CHITTHA APK**.
3. Open the latest successful run (green check mark).
4. Scroll to **Artifacts** and tap **KALA-CHITTHA-debug-apk** to download the ZIP artifact.
5. Extract it. The file inside is `app-debug.apk`. Tap it to install, allowing your browser or file manager to install unknown apps if Android asks.

Every push to `main` also triggers a cloud build automatically. The workflow stores each APK artifact for 14 days.

### Notes

- The repository is private, so your source code is not publicly listed. GitHub Actions build logs and artifacts are accessible to people with repository access.
- This produces a **debug APK**, suitable for personal testing, not a Play Store release. A release build needs a separately managed signing key.
- Never paste a GitHub password, personal access token, PIN, database key, or backup password into chat or commit it to the repository.
- Test PIN setup/recovery, biometric fallback, database encryption, and backup restore with dummy records before storing sensitive information.
