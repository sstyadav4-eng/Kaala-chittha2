package com.kalachittha.app.data

import android.content.Context
import androidx.room.Room
import net.sqlcipher.database.SupportFactory
import com.kalachittha.app.security.DatabaseKey

object DatabaseProvider {
    @Volatile private var instance: KalaDatabase? = null
    fun get(context: Context): KalaDatabase = instance ?: synchronized(this) {
        instance ?: run {
            val passphrase = DatabaseKey.get(context).also { net.sqlcipher.database.SQLiteDatabase.loadLibs(context) }
            Room.databaseBuilder(context, KalaDatabase::class.java, "kala_chittha.db")
                .openHelperFactory(SupportFactory(passphrase))
                .fallbackToDestructiveMigration()
                .build().also { instance = it }
        }
    }
}
