package com.kalachittha.app.security

import android.content.Context
import android.security.keystore.KeyGenParameterSpec
import android.security.keystore.KeyProperties
import android.util.Base64
import java.security.KeyStore
import javax.crypto.Cipher
import javax.crypto.KeyGenerator
import javax.crypto.SecretKey
import javax.crypto.spec.GCMParameterSpec
import javax.crypto.SecretKeyFactory
import javax.crypto.spec.PBEKeySpec
import java.security.SecureRandom

object PinSecurity {
    private const val PREF = "kc_security"
    private const val SALT = "pin_salt"
    private const val HASH = "pin_hash"
    fun isSet(context: Context) = context.getSharedPreferences(PREF, 0).contains(HASH)
    fun setPin(context: Context, pin: String) {
        require(pin.length >= 4 && pin.all(Char::isDigit))
        val salt = ByteArray(16).also { SecureRandom().nextBytes(it) }
        val hash = derive(pin, salt)
        context.getSharedPreferences(PREF, 0).edit()
            .putString(SALT, Base64.encodeToString(salt, Base64.NO_WRAP))
            .putString(HASH, Base64.encodeToString(hash, Base64.NO_WRAP)).apply()
    }
    fun verify(context: Context, pin: String): Boolean {
        val prefs = context.getSharedPreferences(PREF, 0)
        val salt = prefs.getString(SALT, null) ?: return false
        val expected = prefs.getString(HASH, null) ?: return false
        val actual = derive(pin, Base64.decode(salt, Base64.NO_WRAP))
        return java.security.MessageDigest.isEqual(actual, Base64.decode(expected, Base64.NO_WRAP))
    }
    private fun derive(pin: String, salt: ByteArray): ByteArray {
        val spec = PBEKeySpec(pin.toCharArray(), salt, 150_000, 256)
        return SecretKeyFactory.getInstance("PBKDF2WithHmacSHA256").generateSecret(spec).encoded
    }
}

object DatabaseKey {
    private const val ALIAS = "KalaChitthaDbKey"
    private const val PREF = "kc_db_key"
    fun get(context: Context): ByteArray {
        val prefs = context.getSharedPreferences(PREF, 0)
        val encoded = prefs.getString("encrypted", null)
        if (encoded != null) {
            val parts = Base64.decode(encoded, Base64.NO_WRAP)
            val iv = parts.copyOfRange(0, 12)
            val cipherText = parts.copyOfRange(12, parts.size)
            val cipher = Cipher.getInstance("AES/GCM/NoPadding")
            cipher.init(Cipher.DECRYPT_MODE, key(), GCMParameterSpec(128, iv))
            return cipher.doFinal(cipherText)
        }
        val passphrase = ByteArray(32).also { SecureRandom().nextBytes(it) }
        val cipher = Cipher.getInstance("AES/GCM/NoPadding")
        cipher.init(Cipher.ENCRYPT_MODE, key())
        val encrypted = cipher.iv + cipher.doFinal(passphrase)
        prefs.edit().putString("encrypted", Base64.encodeToString(encrypted, Base64.NO_WRAP)).apply()
        return passphrase
    }
    private fun key(): SecretKey {
        val ks = KeyStore.getInstance("AndroidKeyStore").apply { load(null) }
        (ks.getKey(ALIAS, null) as? SecretKey)?.let { return it }
        val generator = KeyGenerator.getInstance(KeyProperties.KEY_ALGORITHM_AES, "AndroidKeyStore")
        generator.init(KeyGenParameterSpec.Builder(ALIAS, KeyProperties.PURPOSE_ENCRYPT or KeyProperties.PURPOSE_DECRYPT)
            .setBlockModes(KeyProperties.BLOCK_MODE_GCM).setEncryptionPaddings(KeyProperties.ENCRYPTION_PADDING_NONE).build())
        return generator.generateKey()
    }
}
